/** @type {import('next').NextConfig} */
const nextConfig = {};

require("next-ws/server").verifyPatch();

module.exports = nextConfig;
