import React from "react";
import PaLocation from "../../PaLocation";

function Locations() {
	return (
		<div className="max-w-lg mx-auto">
			<PaLocation pa={false}></PaLocation>
		</div>
	);
}

export default Locations;
