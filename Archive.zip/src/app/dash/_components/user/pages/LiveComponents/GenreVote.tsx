import React from "react";

function GenreVote({eventId}: {eventId: number}) {
	return (
		<div className="w-full">
			<h2 className="text-center font-mono text-xl">Genre Vote</h2>
		</div>
	);
}

export default GenreVote;
