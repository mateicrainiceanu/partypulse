import POST from "./POST";
import GET from "./GET";
import PATCH from "./PATCH";

export { POST, GET, PATCH }