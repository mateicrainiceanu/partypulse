import { POST } from './post'
import { PATCH } from './patch'
import { GET } from './get'

export { GET, POST, PATCH }